<ul class="social" aria-label="Liens vers les réseaux sociaux">
  <li>
    <a class="social__link" data-social="linkedin" data-variant="white" aria-label="LinkedIn">
      <img src="" alt="">
    </a>
  </li>
  <li>
    <a class="social__link" data-social="facebook" data-variant="white" aria-label="Facebook">
      <img src="" alt="">
    </a>
  </li>
  <li>
    <a class="social__link" data-social="instagram" data-variant="white" aria-label="Instagram">
      <img src="" alt="">
    </a>
  </li>
</ul>