<div class="wrapper-1440-black">
	<section class="program__hero">
		<h1>
			<span>À</span> <span> </span><span>v</span><span>e</span><span>n</span><span>i</span><span>r</span>
		</h1>
	</section>
</div>