<div class="wrapper-1440-black">
	<section class="about__hero scroll-reveal">
		<div class="about__hero__content">
			<p class="about__hero__role">
				<span class="highlight">Fondateur</span> SBG <span class="light">coaching</span>
			</p>
			<h1 class="about__hero__name title">Samuel <br>Billa Garcia
			</h1>
			<blockquote class="about__hero__quote">
				Le seul mauvais entraînement<br>est celui que l’on ne fait pas.
				<span class="about__hero__signature"></span>
			</blockquote>
		</div>

		<div class="about__hero__img"></div>
	</section>
</div>