<noscript>
	<h1 class="title">Mentions légales</h1>
	<p><strong>SBG Coaching</strong><br>
		Route de Yernée 264, 4480 Engis<br>
		TVA : BE 0717.915.212<br>
		Tél : 0494 20 50 75<br>
		Contact : <a href="mailto:info@sbg.be">info@sbg.be</a></p>

	<p>Hébergeur : Hetzner – <a href="https://www.hetzner.com" target="_blank" rel="noopener">www.hetzner.com</a></p>

	<p>Consultez la version complète de nos mentions légales avec JavaScript activé pour voir l’intégralité des clauses RGPD, cookies, données sensibles, responsabilité, etc.</p>
</noscript>