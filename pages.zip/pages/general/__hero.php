<div class="wrapper-1440" id="page__coaching__wrapper__hero">
	<section class="coaching__hero scroll-reveal">
		<div class="coaching__hero-col1">
			<div id="content-main" class="coaching__hero__content">
				<div id="content-1" class="coaching__hero__content__bck coaching__hero__content-bck1">
					<!-- ⚠️ contenu injecté dynamiquement -->
				</div>
			</div>
		</div>

		<div class="wrapper-center">
			<div class="coaching__hero-col2">
				<h2>Actualité</h2>
				<div id="content-2" class="coaching__hero__content coaching__hero__content-secondary coaching__hero__content-secondary1 coaching__hero__content-bck2">
					<a href="#" class="gallery__button">Voir</a>
				</div>
				<div id="content-3" class="coaching__hero__content coaching__hero__content-secondary coaching__hero__content-bck3">
					<a href="#" class="gallery__button">Voir</a>
				</div>
				<div class="coaching__hero__social">
					<?php include 'components/__links-social-black.php'; ?>
				</div>
			</div>
		</div>
	</section>
</div>