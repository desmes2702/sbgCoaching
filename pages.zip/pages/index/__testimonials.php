<div class="wrapper-1440 scroll-reveal">
	<section id="testimonials-index" class="testimonials">
		<h2 class="testimonials__title subTitle">Témoignages</h2>
		<h3 class="testimonials__subtitle title">Des résultats qui parlent</h3>
		<p class="testimonials__intro">Des clients satisfaits qui recommandent SBG Coaching :</p>

		<div class="testimonials__wrapper">
		</div>

		<a class="testimonials__button button button-black" href="testimonials.php">Tout voir</a>
	</section>
</div>