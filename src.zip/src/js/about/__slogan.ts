
const slogan = document.querySelector('.slogan');
if (slogan) slogan.classList.add('active');

// 👇 Ajoute juste ça :
export {};

