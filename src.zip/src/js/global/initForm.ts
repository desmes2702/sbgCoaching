export function initForm(): void {
  console.log("🧠 Le formulaire est initialisé (TypeScript style)");
}
